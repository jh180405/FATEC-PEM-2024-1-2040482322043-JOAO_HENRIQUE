#include <stdio.h>
#include "./h/tabuleiro.h"
#include "./h/jogadas.h"

int main() {
    char tabuleiro[Linha][Coluna][Peca + 1];
    inicializarTabuleiro(tabuleiro);

    imprimirTabelaDeJogadas();
    realizarJogadas(tabuleiro);

    return 0;
}
