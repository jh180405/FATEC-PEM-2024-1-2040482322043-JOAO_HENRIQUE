#ifndef TABULEIRO_H
#define TABULEIRO_H

#define Coluna 8
#define Linha 8
#define Peca 5

void imprimirTabuleiro(char tabuleiro[Linha][Coluna][Peca + 1]);
void inicializarTabuleiro(char tabuleiro[Linha][Coluna][Peca + 1]);

#endif
