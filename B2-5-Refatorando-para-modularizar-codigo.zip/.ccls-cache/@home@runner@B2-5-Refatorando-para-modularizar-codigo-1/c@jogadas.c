#include <stdio.h>
#include <string.h>
#include "../h/jogadas.h"
#include "../h/tabuleiro.h"

void imprimirTabelaDeJogadas() {
    printf("------------------------------------------------------------\n");
    printf("| Jogada | Brancas                  | Pretas               |\n");
    printf("------------------------------------------------------------\n");
    printf("|   1    | Peão do Rei (e1)         | Peão do Rei (e5)     |\n");
    printf("|   2    | Bispo do rei (Bc4)       | Cavalo da Dama (Cc6) |\n");
    printf("|   3    | Dama (Dh5)               | Cavalo do Rei (Cf6)  |\n");
    printf("|   4    | Xeque Mate               |                      |\n");
    printf("------------------------------------------------------------\n");
}

void realizarJogadas(char tabuleiro[Linha][Coluna][Peca + 1]) {
    printf("\nJogada 1:\n");
    strcpy(tabuleiro[4][4], tabuleiro[6][4]);
    strcpy(tabuleiro[6][4], "    ");
    strcpy(tabuleiro[3][4], tabuleiro[1][4]);
    strcpy(tabuleiro[1][4], "    ");
    imprimirTabuleiro(tabuleiro);

    printf("\nJogada 2:\n");
    strcpy(tabuleiro[5][2], tabuleiro[7][5]);
    strcpy(tabuleiro[7][5], "    ");
    strcpy(tabuleiro[2][5], tabuleiro[0][6]);
    strcpy(tabuleiro[0][6], "    ");
    imprimirTabuleiro(tabuleiro);

    printf("\nJogada 3:\n");
    strcpy(tabuleiro[3][7], tabuleiro[7][3]);
    strcpy(tabuleiro[7][3], "    ");
    strcpy(tabuleiro[5][5], tabuleiro[0][6]);
    strcpy(tabuleiro[0][6], "    ");
    imprimirTabuleiro(tabuleiro);

    printf("\nJogada 4: Xeque Mate\n");
    printf("Xeque Mate: Dh5xf7#\n");
}
