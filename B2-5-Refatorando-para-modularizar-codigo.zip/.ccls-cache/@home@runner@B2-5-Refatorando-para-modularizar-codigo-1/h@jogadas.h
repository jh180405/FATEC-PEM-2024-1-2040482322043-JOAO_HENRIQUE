#ifndef JOGADAS_H
#define JOGADAS_H

void imprimirTabelaDeJogadas();
void realizarJogadas(char tabuleiro[8][8][6]);

#endif
